﻿VMware Workstation Pro 26H1 (26.0.1) 繁體中文 ES 相容模式 v1.2

這是非官方中文化研究成果。僅適用 Windows x64 的 VMware Workstation
Pro 26.0.1，build 25688693。不保證其它版本相容。

安裝：
1. 先安裝 VMware Workstation Pro 26.0.1，完全關閉 VMware。
2. 解壓縮此 ZIP（請勿直接在 ZIP 裡執行）。
3. 雙擊 Install.cmd，依照提示允許系統管理員權限。
4. 安裝完成後，使用桌面「VMware Workstation Pro - 繁體中文」啟動。

還原：
關閉 VMware，雙擊 Uninstall.cmd；系統會檢查備份後還原。

注意：
- 本套件包含 VMware 衍生語系 DLL 與文字資源，其著作權屬原權利人。
- 隨附 MIT 授權僅適用本專案原創安裝器程式碼，不適用 VMware 資源。
- 非 VMware / Broadcom 官方支援的語言套件。
- 未確認的再散布、改作與使用權利，請依適用授權自行評估。
- 修改後的 DLL 不再具有有效原廠數位簽章。
- 安裝前請備份工作環境；安裝器不修改 VMware VM 影像檔。

技術概述：
使用 VMware 26.0.1 的 es 資源識別碼，套用繁體中文翻譯，
透過 vmware.exe --locale=es 啟動，避免舊版 zh_TW 載入後
部分對話框退回英文的現象。

GitHub: https://github.com/SuzutsukiLIN/VMware-Workstation-Pro-zh-TW
